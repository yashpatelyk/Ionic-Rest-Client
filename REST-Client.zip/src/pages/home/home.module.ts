import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';

import { HomePage } from './home';
import { RequestComponent } from './request/request.component';

@NgModule({
    imports: [
        IonicPageModule.forChild(HomePage),
        IonicPageModule.forChild(RequestComponent)
    ],

    exports: [],

    declarations: [
        HomePage,
        RequestComponent
    ],

    providers: [],
})
export class HomeModule { }

