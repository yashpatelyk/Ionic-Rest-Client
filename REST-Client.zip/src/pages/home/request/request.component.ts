import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormGroup, FormArray } from "@angular/forms";
import { RestService } from "../../../app/shared/services/rest.service";
import { SUPPORTED_METHODS } from "../../../app/shared/constants/providers";
import { Commons } from "../../../app/shared/utilities/commons";
import { Framework } from "../../../app/shared/utilities/framework";

@Component({
    selector: 'request-form',
    templateUrl: 'request.component.html'
})

export class RequestComponent implements OnInit {

    requestForm: FormGroup;
    defaultHeader: object = {
        isActive: true,
        key: '',
        value: ''
    };

    constructor(
        private fb: FormBuilder,
        @Inject(SUPPORTED_METHODS) private methods: Array<string>,
        private restService: RestService,
        private framework: Framework
    ) { }

    ngOnInit() {
        this.requestForm = this.fb.group({
            method: ['get'],
            url: '',
            hasHeaders: false,
            headers: this.fb.array([
                this.fb.group(this.defaultHeader)
            ]),
            body: ''
        })
    }

    /*
    * methods to be called from the view
    */

    get headers(): any {
        return this.requestForm.get('headers');
    }

    public sendRequest(): void {
        var request:object =  this.constructRequest();

        Commons.log("log", "request object is ",request);

        // call the rest service
        this.restService
            .call(request["method"],request["url"],request["headers"],request["body"])
            .then(response => {
                Commons.log("",response)
            })
            .catch(err => {
                Commons.log("error",err);
                this.framework.showAlert({
                    title: "An error occured",
                    message: "An error occured while processing you request",
                    buttons: ['ok'],
                    enableBackdropDismiss: false
                });

                var self = this;
                setTimeout(function(){
                    self.framework.hideAlert()
                },2000)
            });
    }

    public addNewHeader(): void {
        this.headers.push(this.fb.group(this.defaultHeader))
    }

    /*
    * methods to be called from inside the component/ private methods
    */

    private constructRequest(): object {

        let rawData = this.requestForm.getRawValue();
        let formData = {
            method: rawData.method,
            url: rawData.url,
            headers: {},
            body: ''
        }

        var key = '';
        // include headers if any
        if (rawData.hasHeaders) {
            rawData.headers.forEach(header => {

                // check if header checkbox is checked or not
                if (header.isActive) {
                    formData.headers[header['key']] = header['value'];
                }

            });
        }

        return formData;
    }
}