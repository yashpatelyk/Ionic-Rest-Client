import { Component, Inject } from '@angular/core';
import { NavController } from 'ionic-angular';
import { SUPPORTED_METHODS } from "../../app/shared/constants/providers";
import { RestService } from "../../app/shared/services/rest.service";

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(
    public navCtrl: NavController
  ) { }

  ngOnInit() {

    /*this.restService
      .call("GET", "https://reqres.in/api/users?page=2", {}, null)
      .then(response => console.log(response))
      .catch(err => console.log(err));

    this.restService
      .call("POST", "https://reqres.in/api/users", {}, { "name": "morpheus", "job": "leader" })
      .then(response => console.log(response))
      .catch(err => console.log(err));

    this.restService
      .call("PUT", "https://reqres.in/api/users/2", {}, { "name": "morpheus", "job": "leader" })
      .then(response => console.log(response))
      .catch(err => console.log(err));

      this.restService
      .call("DELETE", "https://reqres.in/api/users/2", {},null)
      .then(response => console.log(response))
      .catch(err => console.log(err));*/
  }

}
