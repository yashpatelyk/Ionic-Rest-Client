import { Injectable } from '@angular/core';
import { AlertController, AlertOptions, Alert } from "ionic-angular";

@Injectable()
export class Framework {

    alert: Alert;

    constructor(
        private alertCtrl: AlertController
    ) { }

    showAlert(opts: AlertOptions): Alert {

        this.alert = this.alertCtrl.create(opts)
        this.alert.present();

        return this.alert;
    }

    hideAlert(): void{
        this.alert.dismiss();
    }
}